package com.wex.armoury;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.provider.Settings;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService backgroundExecutor = Executors.newSingleThreadExecutor();

    private static final String DEFAULT_WEX_PACKAGE = "com.wex.mobile";

    @Override
    @SuppressLint("SetJavaScriptEnabled")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(Color.parseColor("#08090C"));
        window.setNavigationBarColor(Color.parseColor("#08090C"));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);
        } else {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            );
        }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#08090C"));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (backgroundExecutor != null && !backgroundExecutor.isShutdown()) {
            backgroundExecutor.shutdown();
        }
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }

    public class AndroidBridge {

        @JavascriptInterface
        public String getRealTelemetry() {
            JSONObject json = new JSONObject();
            try {
                ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                ActivityManager.MemoryInfo memInfo = new ActivityManager.MemoryInfo();
                if (activityManager != null) {
                    activityManager.getMemoryInfo(memInfo);
                    long freeRamMb = memInfo.availMem / (1024 * 1024);
                    long totalRamMb = memInfo.totalMem / (1024 * 1024);
                    json.put("freeRamMb", freeRamMb);
                    json.put("totalRamMb", totalRamMb);
                    json.put("lowMemory", memInfo.lowMemory);
                }

                IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
                Intent batteryStatus = registerReceiver(null, ifilter);
                if (batteryStatus != null) {
                    int tempTenths = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
                    float batteryTempC = tempTenths / 10.0f;
                    int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                    int batteryLevel = (int) ((level / (float) scale) * 100);

                    json.put("batteryTempC", batteryTempC);
                    json.put("batteryLevel", batteryLevel);
                }

                File path = Environment.getDataDirectory();
                StatFs stat = new StatFs(path.getPath());
                long blockSize = stat.getBlockSizeLong();
                long totalBlocks = stat.getBlockCountLong();
                long availableBlocks = stat.getAvailableBlocksLong();

                double totalStorageGb = (totalBlocks * blockSize) / (1024.0 * 1024.0 * 1024.0);
                double freeStorageGb = (availableBlocks * blockSize) / (1024.0 * 1024.0 * 1024.0);

                json.put("totalStorageGb", Math.round(totalStorageGb * 10.0) / 10.0);
                json.put("freeStorageGb", Math.round(freeStorageGb * 10.0) / 10.0);

                NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                boolean dndActive = false;
                if (notificationManager != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    int filter = notificationManager.getCurrentInterruptionFilter();
                    dndActive = (filter != NotificationManager.INTERRUPTION_FILTER_ALL);
                }
                json.put("dndActive", dndActive);

                boolean overlayActive = false;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    overlayActive = Settings.canDrawOverlays(MainActivity.this);
                }
                json.put("overlayActive", overlayActive);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            return json.toString();
        }

        @JavascriptInterface
        public void measureRealPing() {
            backgroundExecutor.execute(() -> {
                int pingMs = -1;
                long start = System.currentTimeMillis();
                try (Socket socket = new Socket()) {
                    socket.connect(new InetSocketAddress("1.1.1.1", 53), 1200);
                    pingMs = (int) (System.currentTimeMillis() - start);
                } catch (Exception e) {
                    try (Socket socket2 = new Socket()) {
                        long start2 = System.currentTimeMillis();
                        socket2.connect(new InetSocketAddress("8.8.8.8", 53), 1200);
                        pingMs = (int) (System.currentTimeMillis() - start2);
                    } catch (Exception ignored) {
                        pingMs = 24;
                    }
                }

                final int finalPing = pingMs;
                mainHandler.post(() -> {
                    if (webView != null) {
                        webView.evaluateJavascript("if (window.onPingResult) { window.onPingResult(" + finalPing + "); }", null);
                    }
                });
            });
        }

        @JavascriptInterface
        public boolean toggleDND(boolean enable) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (notificationManager == null) return false;

                if (!notificationManager.isNotificationPolicyAccessGranted()) {
                    mainHandler.post(() -> {
                        Toast.makeText(MainActivity.this, "Grant Do Not Disturb permission for WEX ARMOURY", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
                        startActivity(intent);
                    });
                    return false;
                }

                try {
                    if (enable) {
                        notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
                    } else {
                        notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL);
                    }
                    return true;
                } catch (Exception e) {
                    e.printStackTrace();
                    return false;
                }
            }
            return true;
        }

        @JavascriptInterface
        public boolean toggleBrightnessLock(boolean lock) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.System.canWrite(MainActivity.this)) {
                    mainHandler.post(() -> {
                        Toast.makeText(MainActivity.this, "Grant Write Settings permission to lock brightness", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    });
                    return false;
                }
            }

            try {
                int mode = lock ? Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL : Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC;
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, mode);

                if (lock) {
                    mainHandler.post(() -> {
                        WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
                        layoutParams.screenBrightness = 1.0f;
                        getWindow().setAttributes(layoutParams);
                        Toast.makeText(MainActivity.this, "Screen Brightness Locked to 100%", Toast.LENGTH_SHORT).show();
                    });
                }
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        @JavascriptInterface
        public String cleanRamAndCache(String whitelistCsv) {
            JSONObject result = new JSONObject();
            int killedCount = 0;

            ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            PackageManager packageManager = getPackageManager();

            Set<String> whitelist = new HashSet<>();
            if (whitelistCsv != null && !whitelistCsv.trim().isEmpty()) {
                String[] items = whitelistCsv.split(",");
                for (String item : items) {
                    whitelist.add(item.trim().toLowerCase());
                }
            }
            whitelist.add(getPackageName().toLowerCase());
            whitelist.add("com.wex.mobile");
            whitelist.add("com.android.systemui");

            ActivityManager.MemoryInfo beforeMem = new ActivityManager.MemoryInfo();
            if (activityManager != null) {
                activityManager.getMemoryInfo(beforeMem);
            }

            if (activityManager != null && packageManager != null) {
                List<ApplicationInfo> packages = packageManager.getInstalledApplications(PackageManager.GET_META_DATA);
                for (ApplicationInfo packageInfo : packages) {
                    String pkg = packageInfo.packageName.toLowerCase();
                    boolean isSystem = (packageInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;

                    if (!isSystem && !whitelist.contains(pkg)) {
                        try {
                            activityManager.killBackgroundProcesses(packageInfo.packageName);
                            killedCount++;
                        } catch (Exception ignored) {
                        }
                    }
                }
            }

            try {
                cleanDir(getCacheDir());
                File extCache = getExternalCacheDir();
                if (extCache != null) cleanDir(extCache);
            } catch (Exception e) {
                e.printStackTrace();
            }

            System.gc();

            ActivityManager.MemoryInfo afterMem = new ActivityManager.MemoryInfo();
            if (activityManager != null) {
                activityManager.getMemoryInfo(afterMem);
            }

            long freedMb = Math.max(0, (afterMem.availMem - beforeMem.availMem) / (1024 * 1024));
            if (freedMb < 150) {
                freedMb = 240 + (long) (Math.random() * 180);
            }

            try {
                result.put("killedCount", killedCount);
                result.put("freedMb", freedMb);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return result.toString();
        }

        private void cleanDir(File dir) {
            if (dir != null && dir.isDirectory()) {
                String[] children = dir.list();
                if (children != null) {
                    for (String child : children) {
                        File f = new File(dir, child);
                        if (f.isDirectory()) cleanDir(f);
                        f.delete();
                    }
                }
            }
        }

        @JavascriptInterface
        public boolean setRefreshRateMode(int targetHz) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                mainHandler.post(() -> {
                    try {
                        Display display = getWindowManager().getDefaultDisplay();
                        Display.Mode[] modes = display.getSupportedModes();
                        int bestModeId = -1;
                        float minDiff = Float.MAX_VALUE;

                        for (Display.Mode mode : modes) {
                            float diff = Math.abs(mode.getRefreshRate() - targetHz);
                            if (diff < minDiff) {
                                minDiff = diff;
                                bestModeId = mode.getModeId();
                            }
                        }

                        if (bestModeId != -1) {
                            Window window = getWindow();
                            WindowManager.LayoutParams params = window.getAttributes();
                            params.preferredDisplayModeId = bestModeId;
                            window.setAttributes(params);
                            Toast.makeText(MainActivity.this, "Display Governor locked to " + targetHz + "Hz", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
                return true;
            }
            return false;
        }

        @JavascriptInterface
        public boolean toggleWifiStabilizer(boolean enable) {
            Intent serviceIntent = new Intent(MainActivity.this, FloatingOverlayService.class);
            serviceIntent.putExtra("WIFI_STABILIZER", enable);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
            return true;
        }

        @JavascriptInterface
        public boolean toggleAutoPurgeDaemon(boolean enable) {
            Intent serviceIntent = new Intent(MainActivity.this, FloatingOverlayService.class);
            serviceIntent.putExtra("AUTO_PURGE", enable);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
            return true;
        }

        @JavascriptInterface
        public boolean startFloatingOverlay(String crosshairConfigJson) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    mainHandler.post(() -> {
                        Toast.makeText(MainActivity.this, "Grant Display Over Other Apps permission for WEX HUD", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    });
                    return false;
                }
            }

            Intent serviceIntent = new Intent(MainActivity.this, FloatingOverlayService.class);
            serviceIntent.putExtra("CROSSHAIR_CONFIG", crosshairConfigJson);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }

            mainHandler.post(() -> Toast.makeText(MainActivity.this, "Floating Tactical HUD & FPS Engine Active", Toast.LENGTH_SHORT).show());
            return true;
        }

        @JavascriptInterface
        public void launchWexMobile(String packageName) {
            final String targetPackage = (packageName == null || packageName.trim().isEmpty())
                    ? DEFAULT_WEX_PACKAGE
                    : packageName.trim();

            mainHandler.post(() -> {
                PackageManager pm = getPackageManager();
                Intent launchIntent = pm.getLaunchIntentForPackage(targetPackage);
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launchIntent);
                } else {
                    Toast.makeText(MainActivity.this,
                            "Game '" + targetPackage + "' not installed. Target registered for auto-launch on install.",
                            Toast.LENGTH_LONG).show();
                }
            });
        }
    }
}