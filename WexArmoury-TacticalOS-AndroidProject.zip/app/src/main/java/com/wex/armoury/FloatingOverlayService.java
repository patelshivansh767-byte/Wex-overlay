package com.wex.armoury;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import org.json.JSONObject;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FloatingOverlayService extends Service implements Choreographer.FrameCallback {

    private static final String CHANNEL_ID = "wex_armoury_overlay_channel";
    private static final int NOTIFICATION_ID = 9021;

    private WindowManager windowManager;

    private View pillView;
    private WindowManager.LayoutParams pillParams;
    private TextView pillFpsText;
    private TextView pillPingText;
    private TextView pillTempText;

    private View hudPanelView;
    private WindowManager.LayoutParams hudParams;
    private boolean isHudExpanded = false;
    private TextView hudFpsValue;
    private TextView hudPingValue;
    private TextView hudRamValue;
    private TextView hudTempValue;

    private CrosshairOverlayView crosshairView;
    private WindowManager.LayoutParams crosshairParams;
    private boolean isCrosshairVisible = true;

    private String crosshairShape = "CROSS";
    private int crosshairColor = Color.parseColor("#FF2A3C");
    private int crosshairSize = 28;
    private int crosshairThickness = 3;
    private int offsetX = 0;
    private int offsetY = 0;

    private long lastFrameTimeNanos = 0;
    private int frameCount = 0;
    private long lastFpsUpdateTime = 0;
    private int currentFps = 120;
    private int droppedFrames = 0;

    private WifiManager.WifiLock wifiLock;
    private boolean isWifiStabilizerActive = true;
    private int currentPingMs = 18;

    private boolean isAutoPurgeDaemonActive = true;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService backgroundExecutor = Executors.newFixedThreadPool(2);
    private Runnable autoPurgeRunnable;
    private Runnable telemetryPoller;

    private final Set<String> protectedWhitelist = new HashSet<>();

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        try {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY);
        } catch (Exception ignored) {
        }

        initDefaultWhitelist();
        initWifiStabilizer();
        startForegroundWithNotification();
        initLayers();

        Choreographer.getInstance().postFrameCallback(this);
        startAutoPurgeDaemon();
        startTelemetryLoop();
    }

    private void initDefaultWhitelist() {
        protectedWhitelist.add(getPackageName().toLowerCase());
        protectedWhitelist.add("com.wex.mobile");
        protectedWhitelist.add("com.discord");
        protectedWhitelist.add("com.spotify.music");
        protectedWhitelist.add("com.hecorat.screenrecorder.free");
        protectedWhitelist.add("com.android.systemui");
    }

    private void initWifiStabilizer() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "WexArmoury:LowLatencyPingLock");
                } else {
                    wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "WexArmoury:HighPerfPingLock");
                }
                wifiLock.setReferenceCounted(false);
                if (isWifiStabilizerActive) {
                    wifiLock.acquire();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            if (intent.hasExtra("CROSSHAIR_CONFIG")) {
                parseCrosshairConfig(intent.getStringExtra("CROSSHAIR_CONFIG"));
            }
            if (intent.hasExtra("WIFI_STABILIZER")) {
                setWifiStabilizerEnabled(intent.getBooleanExtra("WIFI_STABILIZER", true));
            }
            if (intent.hasExtra("AUTO_PURGE")) {
                setAutoPurgeEnabled(intent.getBooleanExtra("AUTO_PURGE", true));
            }
        }
        return START_STICKY;
    }

    @Override
    public void doFrame(long frameTimeNanos) {
        if (lastFrameTimeNanos != 0) {
            frameCount++;
            long elapsedNanos = frameTimeNanos - lastFrameTimeNanos;
            long elapsedMs = elapsedNanos / 1_000_000;
            if (elapsedMs > 13) droppedFrames++;

            long now = System.currentTimeMillis();
            if (now - lastFpsUpdateTime >= 800) {
                float seconds = (now - lastFpsUpdateTime) / 1000.0f;
                currentFps = Math.max(1, Math.round(frameCount / seconds));
                frameCount = 0;
                lastFpsUpdateTime = now;
                updateFpsUI(currentFps);
            }
        } else {
            lastFpsUpdateTime = System.currentTimeMillis();
        }
        lastFrameTimeNanos = frameTimeNanos;
        Choreographer.getInstance().postFrameCallback(this);
    }

    private void updateFpsUI(int fps) {
        if (pillFpsText != null) {
            pillFpsText.setText(fps + " FPS");
            if (fps >= 100) pillFpsText.setTextColor(Color.parseColor("#00E676"));
            else if (fps >= 75) pillFpsText.setTextColor(Color.parseColor("#00E5FF"));
            else pillFpsText.setTextColor(Color.parseColor("#FFB020"));
        }
        if (hudFpsValue != null) hudFpsValue.setText(fps + " FPS");
    }

    private void startForegroundWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "WEX Tactical HUD & Esports Engine",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Accurate Live FPS, Ping Stabilizer, and Floating HUD over WEX Mobile");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }

        Intent openAppIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, openAppIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("WEX ARMOURY // ESPORTS ENGINE ENGAGED")
                .setContentText("Live FPS Engine · Wi-Fi Ping Stabilizer · Reticle Active")
                .setSmallIcon(android.R.drawable.ic_dialog_dialer)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void parseCrosshairConfig(String json) {
        if (json == null) return;
        try {
            JSONObject obj = new JSONObject(json);
            if (obj.has("shape")) crosshairShape = obj.getString("shape");
            if (obj.has("color")) crosshairColor = Color.parseColor(obj.getString("color"));
            if (obj.has("size")) crosshairSize = obj.getInt("size");
            if (obj.has("thickness")) crosshairThickness = obj.getInt("thickness");
            if (obj.has("offsetX")) offsetX = obj.getInt("offsetX");
            if (obj.has("offsetY")) offsetY = obj.getInt("offsetY");

            if (crosshairView != null) {
                crosshairView.updateConfig(crosshairShape, crosshairColor, crosshairSize, crosshairThickness, offsetX, offsetY);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private void initLayers() {
        int overlayType = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        Point screenSize = new Point();
        windowManager.getDefaultDisplay().getRealSize(screenSize);

        crosshairView = new CrosshairOverlayView(this);
        crosshairView.updateConfig(crosshairShape, crosshairColor, crosshairSize, crosshairThickness, offsetX, offsetY);

        crosshairParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
        );
        crosshairParams.gravity = Gravity.CENTER;

        try {
            windowManager.addView(crosshairView, crosshairParams);
        } catch (Exception e) {
            e.printStackTrace();
        }

        pillView = createMiniTelemetryPillView();
        pillParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                dpToPx(38),
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        pillParams.gravity = Gravity.TOP | Gravity.START;
        pillParams.x = 0;
        pillParams.y = screenSize.y / 4;

        setupPillTouchListener(screenSize);

        try {
            windowManager.addView(pillView, pillParams);
        } catch (Exception e) {
            e.printStackTrace();
        }

        hudPanelView = createFullTacticalDashboardView();
        hudParams = new WindowManager.LayoutParams(
                dpToPx(320),
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        hudParams.gravity = Gravity.TOP | Gravity.START;
        hudParams.x = dpToPx(8);
        hudParams.y = pillParams.y + dpToPx(44);

        hudPanelView.setVisibility(View.GONE);
        try {
            windowManager.addView(hudPanelView, hudParams);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private View createMiniTelemetryPillView() {
        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setBackgroundColor(Color.parseColor("#E608090C"));
        pill.setPadding(dpToPx(6), dpToPx(4), dpToPx(10), dpToPx(4));

        View ledTab = new View(this);
        LinearLayout.LayoutParams ledParams = new LinearLayout.LayoutParams(dpToPx(4), dpToPx(24));
        ledParams.setMargins(0, 0, dpToPx(8), 0);
        ledTab.setLayoutParams(ledParams);
        ledTab.setBackgroundColor(Color.parseColor("#00E676"));
        pill.addView(ledTab);

        pillFpsText = new TextView(this);
        pillFpsText.setText("120 FPS");
        pillFpsText.setTextColor(Color.parseColor("#00E676"));
        pillFpsText.setTextSize(11f);
        pillFpsText.setTypeface(android.graphics.Typeface.MONOSPACE);
        pill.addView(pillFpsText);

        pill.addView(createDotSeparator());

        pillPingText = new TextView(this);
        pillPingText.setText("18 MS");
        pillPingText.setTextColor(Color.parseColor("#00E5FF"));
        pillPingText.setTextSize(10f);
        pillPingText.setTypeface(android.graphics.Typeface.MONOSPACE);
        pill.addView(pillPingText);

        pill.addView(createDotSeparator());

        pillTempText = new TextView(this);
        pillTempText.setText("34°C");
        pillTempText.setTextColor(Color.parseColor("#FFB020"));
        pillTempText.setTextSize(10f);
        pillTempText.setTypeface(android.graphics.Typeface.MONOSPACE);
        pill.addView(pillTempText);

        return pill;
    }

    private TextView createDotSeparator() {
        TextView dot = new TextView(this);
        dot.setText(" · ");
        dot.setTextColor(Color.parseColor("#6B7280"));
        dot.setTextSize(10f);
        return dot;
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupPillTouchListener(Point screenSize) {
        pillView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private long touchStartTime;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = pillParams.x;
                        initialY = pillParams.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        touchStartTime = System.currentTimeMillis();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        pillParams.x = initialX + (int) (event.getRawX() - initialTouchX);
                        pillParams.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(pillView, pillParams);

                        if (isHudExpanded) {
                            hudParams.y = Math.min(screenSize.y - dpToPx(380), pillParams.y + dpToPx(44));
                            hudParams.x = Math.max(dpToPx(8), Math.min(pillParams.x, screenSize.x - dpToPx(330)));
                            windowManager.updateViewLayout(hudPanelView, hudParams);
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                        long duration = System.currentTimeMillis() - touchStartTime;
                        float diffX = Math.abs(event.getRawX() - initialTouchX);
                        float diffY = Math.abs(event.getRawY() - initialTouchY);

                        if (duration < 240 && diffX < 14 && diffY < 14) {
                            toggleHudPanel(screenSize);
                            return true;
                        }

                        int screenMid = screenSize.x / 2;
                        if (pillParams.x < screenMid) pillParams.x = 0;
                        else pillParams.x = screenSize.x - pillView.getWidth();
                        windowManager.updateViewLayout(pillView, pillParams);
                        return true;
                }
                return false;
            }
        });
    }

    private void toggleHudPanel(Point screenSize) {
        isHudExpanded = !isHudExpanded;
        if (isHudExpanded) {
            hudParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            hudParams.y = Math.max(dpToPx(16), Math.min(pillParams.y + dpToPx(44), screenSize.y - dpToPx(420)));
            hudParams.x = Math.max(dpToPx(8), Math.min(pillParams.x, screenSize.x - dpToPx(328)));
            hudPanelView.setVisibility(View.VISIBLE);
            windowManager.updateViewLayout(hudPanelView, hudParams);
        } else {
            hudParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            hudPanelView.setVisibility(View.GONE);
            windowManager.updateViewLayout(hudPanelView, hudParams);
        }
    }

    private View createFullTacticalDashboardView() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.parseColor("#F208090C"));
        panel.setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(12));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dpToPx(8));

        TextView title = new TextView(this);
        title.setText("WEX ARMOURY // GAME SPACE");
        title.setTextColor(Color.parseColor("#00E5FF"));
        title.setTextSize(11f);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams tLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        title.setLayoutParams(tLp);
        header.addView(title);

        Button closeBtn = new Button(this);
        closeBtn.setText("✕");
        closeBtn.setTextColor(Color.parseColor("#9CA3AF"));
        closeBtn.setBackgroundColor(Color.TRANSPARENT);
        closeBtn.setTextSize(12f);
        closeBtn.setLayoutParams(new LinearLayout.LayoutParams(dpToPx(28), dpToPx(28)));
        closeBtn.setOnClickListener(v -> {
            Point pt = new Point();
            windowManager.getDefaultDisplay().getRealSize(pt);
            toggleHudPanel(pt);
        });
        header.addView(closeBtn);
        panel.addView(header);

        LinearLayout telemStrip = new LinearLayout(this);
        telemStrip.setOrientation(LinearLayout.HORIZONTAL);
        telemStrip.setBackgroundColor(Color.parseColor("#101218"));
        telemStrip.setPadding(dpToPx(8), dpToPx(6), dpToPx(8), dpToPx(6));

        hudFpsValue = createMetricBadge("FPS", currentFps + " FPS", "#00E676");
        telemStrip.addView(hudFpsValue);

        hudPingValue = createMetricBadge("PING", currentPingMs + " MS", "#00E5FF");
        telemStrip.addView(hudPingValue);

        hudTempValue = createMetricBadge("TEMP", "34°C", "#FFB020");
        telemStrip.addView(hudTempValue);

        hudRamValue = createMetricBadge("FREE RAM", "3.4 GB", "#FFF");
        telemStrip.addView(hudRamValue);

        panel.addView(telemStrip);

        panel.addView(createSectionHeader("EXTREME GAME FOCUS // BOOST"));

        panel.addView(createActionButton("⚡ 1-TAP DEEP RAM & CACHE PURGE", "#00E676", v -> {
            executeEmergencyRamPurge();
        }));

        final Button wifiBtn = createActionButton(
                isWifiStabilizerActive ? "📶 PING STABILIZER: ACTIVE [WI-FI LOCKED]" : "📶 PING STABILIZER: OFF",
                isWifiStabilizerActive ? "#00E5FF" : "#9CA3AF",
                null
        );
        wifiBtn.setOnClickListener(v -> {
            isWifiStabilizerActive = !isWifiStabilizerActive;
            setWifiStabilizerEnabled(isWifiStabilizerActive);
            wifiBtn.setText(isWifiStabilizerActive ? "📶 PING STABILIZER: ACTIVE [WI-FI LOCKED]" : "📶 PING STABILIZER: OFF");
            wifiBtn.setTextColor(Color.parseColor(isWifiStabilizerActive ? "#00E5FF" : "#9CA3AF"));
        });
        panel.addView(wifiBtn);

        final Button daemonBtn = createActionButton(
                isAutoPurgeDaemonActive ? "🛡 AUTO-KILL BG PROCESSES: 30s DAEMON ON" : "🛡 AUTO-KILL BG PROCESSES: OFF",
                isAutoPurgeDaemonActive ? "#FFB020" : "#9CA3AF",
                null
        );
        daemonBtn.setOnClickListener(v -> {
            isAutoPurgeDaemonActive = !isAutoPurgeDaemonActive;
            setAutoPurgeEnabled(isAutoPurgeDaemonActive);
            daemonBtn.setText(isAutoPurgeDaemonActive ? "🛡 AUTO-KILL BG PROCESSES: 30s DAEMON ON" : "🛡 AUTO-KILL BG PROCESSES: OFF");
            daemonBtn.setTextColor(Color.parseColor(isAutoPurgeDaemonActive ? "#FFB020" : "#9CA3AF"));
        });
        panel.addView(daemonBtn);

        panel.addView(createSectionHeader("CLICK-THROUGH RETICLE CALIBRATOR"));

        LinearLayout shapeRow = new LinearLayout(this);
        shapeRow.setOrientation(LinearLayout.HORIZONTAL);
        shapeRow.setWeightSum(4);
        shapeRow.addView(createMiniShapeBtn("CROSS", "CROSS"));
        shapeRow.addView(createMiniShapeBtn("DOT", "DOT"));
        shapeRow.addView(createMiniShapeBtn("CIRC", "CIRCLE_DOT"));
        shapeRow.addView(createMiniShapeBtn("T-POST", "T_POST"));
        panel.addView(shapeRow);

        LinearLayout offsetBar = new LinearLayout(this);
        offsetBar.setOrientation(LinearLayout.HORIZONTAL);
        offsetBar.setGravity(Gravity.CENTER_VERTICAL);
        offsetBar.setPadding(0, dpToPx(4), 0, dpToPx(4));

        TextView offLabel = new TextView(this);
        offLabel.setText("NUDGE AIM: ");
        offLabel.setTextColor(Color.parseColor("#9CA3AF"));
        offLabel.setTextSize(9f);
        offsetBar.addView(offLabel);

        offsetBar.addView(createOffsetNudgeBtn("X-", -1, 0));
        offsetBar.addView(createOffsetNudgeBtn("X+", 1, 0));
        offsetBar.addView(createOffsetNudgeBtn("Y-", 0, -1));
        offsetBar.addView(createOffsetNudgeBtn("Y+", 0, 1));

        Button resetBtn = new Button(this);
        resetBtn.setText("RESET [0,0]");
        resetBtn.setTextColor(Color.parseColor("#FF2A3C"));
        resetBtn.setBackgroundColor(Color.parseColor("#1B1F2A"));
        resetBtn.setTextSize(8f);
        resetBtn.setPadding(dpToPx(6), 0, dpToPx(6), 0);
        resetBtn.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dpToPx(24)));
        resetBtn.setOnClickListener(v -> {
            offsetX = 0;
            offsetY = 0;
            crosshairView.updateConfig(crosshairShape, crosshairColor, crosshairSize, crosshairThickness, 0, 0);
            Toast.makeText(FloatingOverlayService.this, "Reticle Centered", Toast.LENGTH_SHORT).show();
        });
        offsetBar.addView(resetBtn);

        panel.addView(offsetBar);

        return panel;
    }

    private TextView createMetricBadge(String label, String initialVal, String hexColor) {
        TextView tv = new TextView(this);
        tv.setText(label + "
" + initialVal);
        tv.setTextColor(Color.parseColor(hexColor));
        tv.setTextSize(9f);
        tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        tv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tv.setLayoutParams(lp);
        return tv;
    }

    private TextView createSectionHeader(String title) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextColor(Color.parseColor("#6B7280"));
        tv.setTextSize(8.5f);
        tv.setPadding(0, dpToPx(6), 0, dpToPx(2));
        tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return tv;
    }

    private Button createActionButton(String label, String hexColor, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setTextColor(Color.parseColor(hexColor));
        btn.setBackgroundColor(Color.parseColor("#151922"));
        btn.setTextSize(9.5f);
        btn.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(32));
        lp.setMargins(0, dpToPx(2), 0, dpToPx(2));
        btn.setLayoutParams(lp);
        if (listener != null) btn.setOnClickListener(listener);
        return btn;
    }

    private Button createMiniShapeBtn(String label, String shapeKey) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setTextColor(Color.parseColor("#FFF"));
        btn.setBackgroundColor(Color.parseColor("#1B1F2A"));
        btn.setTextSize(8.5f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dpToPx(26), 1f);
        lp.setMargins(dpToPx(1), 0, dpToPx(1), 0);
        btn.setLayoutParams(lp);
        btn.setOnClickListener(v -> {
            crosshairShape = shapeKey;
            crosshairView.updateConfig(crosshairShape, crosshairColor, crosshairSize, crosshairThickness, offsetX, offsetY);
        });
        return btn;
    }

    private Button createOffsetNudgeBtn(String label, int dx, int dy) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setTextColor(Color.parseColor("#00E5FF"));
        btn.setBackgroundColor(Color.parseColor("#151922"));
        btn.setTextSize(8f);
        btn.setLayoutParams(new LinearLayout.LayoutParams(dpToPx(34), dpToPx(24)));
        btn.setOnClickListener(v -> {
            offsetX += dx;
            offsetY += dy;
            crosshairView.updateConfig(crosshairShape, crosshairColor, crosshairSize, crosshairThickness, offsetX, offsetY);
        });
        return btn;
    }

    private void executeEmergencyRamPurge() {
        backgroundExecutor.execute(() -> {
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            PackageManager pm = getPackageManager();
            int killed = 0;

            if (am != null && pm != null) {
                List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
                for (ApplicationInfo app : apps) {
                    String pkg = app.packageName.toLowerCase();
                    boolean isSystem = (app.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                    if (!isSystem && !protectedWhitelist.contains(pkg)) {
                        try {
                            am.killBackgroundProcesses(app.packageName);
                            killed++;
                        } catch (Exception ignored) {
                        }
                    }
                }
            }

            System.gc();
            final int finalKilled = killed;

            mainHandler.post(() -> {
                Toast.makeText(FloatingOverlayService.this,
                        "Deep Purge Complete: " + finalKilled + " background apps terminated",
                        Toast.LENGTH_SHORT).show();
            });
        });
    }

    public void setWifiStabilizerEnabled(boolean enabled) {
        isWifiStabilizerActive = enabled;
        if (wifiLock != null) {
            try {
                if (enabled && !wifiLock.isHeld()) {
                    wifiLock.acquire();
                } else if (!enabled && wifiLock.isHeld()) {
                    wifiLock.release();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void setAutoPurgeEnabled(boolean enabled) {
        isAutoPurgeDaemonActive = enabled;
    }

    private void startAutoPurgeDaemon() {
        autoPurgeRunnable = new Runnable() {
            @Override
            public void run() {
                if (isAutoPurgeDaemonActive) {
                    executeEmergencyRamPurge();
                }
                mainHandler.postDelayed(this, 30_000);
            }
        };
        mainHandler.postDelayed(autoPurgeRunnable, 30_000);
    }

    private void startTelemetryLoop() {
        telemetryPoller = new Runnable() {
            @Override
            public void run() {
                backgroundExecutor.execute(() -> {
                    long start = System.currentTimeMillis();
                    try (Socket socket = new Socket()) {
                        socket.connect(new InetSocketAddress("1.1.1.1", 53), 1000);
                        currentPingMs = (int) (System.currentTimeMillis() - start);
                    } catch (Exception e) {
                        currentPingMs = 18;
                    }

                    mainHandler.post(() -> {
                        if (pillPingText != null) pillPingText.setText(currentPingMs + " MS");
                        if (hudPingValue != null) hudPingValue.setText("PING
" + currentPingMs + " MS");
                    });
                });

                IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
                Intent bIntent = registerReceiver(null, ifilter);
                if (bIntent != null) {
                    float temp = bIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0f;
                    if (pillTempText != null) pillTempText.setText(Math.round(temp) + "°C");
                    if (hudTempValue != null) hudTempValue.setText("TEMP
" + temp + "°C");
                }

                ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                if (am != null) {
                    ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                    am.getMemoryInfo(mi);
                    long freeMb = mi.availMem / (1024 * 1024);
                    if (hudRamValue != null) {
                        hudRamValue.setText("FREE RAM
" + (freeMb / 1024.0 > 1.0 ? String.format("%.1f GB", freeMb / 1024.0) : freeMb + " MB"));
                    }
                }

                mainHandler.postDelayed(this, 1800);
            }
        };
        mainHandler.post(telemetryPoller);
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    @Override
    public void onDestroy() {
        if (autoPurgeRunnable != null) mainHandler.removeCallbacks(autoPurgeRunnable);
        if (telemetryPoller != null) mainHandler.removeCallbacks(telemetryPoller);
        Choreographer.getInstance().removeFrameCallback(this);

        if (wifiLock != null && wifiLock.isHeld()) {
            wifiLock.release();
        }
        if (backgroundExecutor != null) {
            backgroundExecutor.shutdown();
        }

        if (windowManager != null) {
            if (pillView != null) windowManager.removeView(pillView);
            if (hudPanelView != null) windowManager.removeView(hudPanelView);
            if (crosshairView != null) windowManager.removeView(crosshairView);
        }
        super.onDestroy();
    }

    public static class CrosshairOverlayView extends View {

        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private String shape = "CROSS";
        private int color = Color.RED;
        private int size = 28;
        private int thickness = 3;
        private int offX = 0;
        private int offY = 0;

        public CrosshairOverlayView(Context context) {
            super(context);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.SQUARE);
        }

        public void updateConfig(String shape, int color, int size, int thickness, int offX, int offY) {
            this.shape = shape;
            this.color = color;
            this.size = size;
            this.thickness = thickness;
            this.offX = offX;
            this.offY = offY;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            float cx = (getWidth() / 2.0f) + offX;
            float cy = (getHeight() / 2.0f) + offY;
            float half = size / 2.0f;

            paint.setColor(color);
            paint.setStrokeWidth(thickness);

            switch (shape.toUpperCase()) {
                case "DOT":
                    paint.setStyle(Paint.Style.FILL);
                    canvas.drawCircle(cx, cy, Math.max(2, thickness), paint);
                    break;

                case "CIRCLE_DOT":
                    paint.setStyle(Paint.Style.STROKE);
                    canvas.drawCircle(cx, cy, half, paint);
                    paint.setStyle(Paint.Style.FILL);
                    canvas.drawCircle(cx, cy, Math.max(2, thickness - 1), paint);
                    break;

                case "T_POST":
                    paint.setStyle(Paint.Style.STROKE);
                    canvas.drawLine(cx - half, cy, cx - 4, cy, paint);
                    canvas.drawLine(cx + 4, cy, cx + half, cy, paint);
                    canvas.drawLine(cx, cy + 4, cx, cy + half, paint);
                    paint.setStyle(Paint.Style.FILL);
                    canvas.drawCircle(cx, cy, 2, paint);
                    break;

                case "CROSS":
                default:
                    paint.setStyle(Paint.Style.STROKE);
                    canvas.drawLine(cx - half, cy, cx - 4, cy, paint);
                    canvas.drawLine(cx + 4, cy, cx + half, cy, paint);
                    canvas.drawLine(cx, cy - half, cx, cy - 4, paint);
                    canvas.drawLine(cx, cy + 4, cx, cy + half, paint);
                    paint.setStyle(Paint.Style.FILL);
                    canvas.drawCircle(cx, cy, Math.max(1.5f, thickness * 0.4f), paint);
                    break;
            }
        }
    }
}